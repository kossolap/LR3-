#ifndef LR3_AVL_TREE_H
#define LR3_AVL_TREE_H

#include <cstddef>
#include <string>
#include <vector>

namespace lr3 {

class AVLTree {
private:
    struct Node {
        std::string key;
        int height;
        Node* left;
        Node* right;

        explicit Node(const std::string& value);
    };

    Node* root_;
    std::size_t size_;

    int height(Node* node) const;
    int balanceFactor(Node* node) const;
    void updateHeight(Node* node);

    Node* rotateRight(Node* node);
    Node* rotateLeft(Node* node);
    Node* balance(Node* node);

    Node* insert(Node* node, const std::string& key);
    Node* remove(Node* node, const std::string& key);
    Node* findMin(Node* node) const;
    Node* removeMin(Node* node);

    bool contains(Node* node, const std::string& key) const;
    void inOrder(Node* node, std::vector<std::string>& result) const;
    void destroy(Node* node) noexcept;
    Node* clone(Node* node);

public:
    AVLTree();
    AVLTree(const AVLTree& other);
    AVLTree& operator=(const AVLTree& other);
    ~AVLTree();

    void insert(const std::string& key);
    bool remove(const std::string& key);
    bool contains(const std::string& key) const;

    std::size_t size() const noexcept;
    bool empty() const noexcept;
    int height() const;

    void clear() noexcept;
    std::vector<std::string> toVector() const;
};

}

#endif